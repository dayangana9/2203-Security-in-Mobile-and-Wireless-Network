package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {

    FirebaseAuth mAuth;
    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mAuth = FirebaseAuth.getInstance();
        logout = findViewById(R.id.logout);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    mAuth.signOut();
                    startActivity(new Intent(HomeActivity.this, MainActivity.class));
                    finish();
                } catch (Exception e) {
                    // Handle the error, e.g., show a message to the user
                    Toast.makeText(HomeActivity.this, "Logout failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}